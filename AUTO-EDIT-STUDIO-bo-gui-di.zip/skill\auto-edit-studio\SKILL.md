---
name: auto-edit-studio
description: Dựng clip dọc 9:16 cảm xúc từ ảnh/video một ca đỡ đẻ (sinh con) để đăng TikTok/Facebook, hoặc viết kịch bản phụ đề và file mẫu .json cho app Auto Edit Studio. Dùng khi người dùng nói tới ca đỡ đẻ, ca sinh, mẹ và bé, nhả vía, clip khoảnh khắc đầu đời, hoặc đưa một thư mục ảnh ca sinh và muốn ra clip. Cũng dùng khi họ nhắc "Auto Edit Studio", "mẫu .json", hay muốn đổi kịch bản/nhịp cắt/màu chữ của app này.
---

# Auto Edit Studio

Bộ này gồm một app HTML chạy một mình (`assets/auto-edit-studio.html`) và một file
mẫu (`assets/mau-ca-do-de.json`). App tự cắt cảnh, rải phụ đề, làm Ken Burns, nối
outro và xuất mp4 dọc. Phần Claude làm trong skill này là **viết kịch bản và nặn
file mẫu** — đúng cái app không tự nghĩ ra được.

## Việc đầu tiên: hỏi cho đủ, đừng đoán

Trước khi viết chữ nào, cần biết:

- tên bác sĩ (`bs`) và tên bệnh viện / phòng khám (`bv`, `pk`);
- bé trai hay bé gái, có tên chưa (`be`) — không có thì để rỗng, đừng bịa;
- clip dài bao nhiêu giây (`total`, mặc định 42; app có sẵn 3 nút 28/42/60).
  Khung này vốn dựng cho clip 15–30 giây, và xem hết + xem lại là tín hiệu phân phối
  mạnh nhất — ít ảnh hoặc muốn chắc người ta xem tới cuối thì **chốt 28**;
- đăng cho trang cá nhân hay Trang của phòng khám (ảnh hưởng tới nhạc, xem phần
  bản quyền dưới).

Nếu người dùng đã đưa thư mục ảnh, đếm số ảnh trước rồi mới chốt `total`:
`total / hold` ra số cảnh, mà số cảnh không nên vượt số ảnh dùng được.

## Viết kịch bản: 5 nhịp, giọng phải thật

Mẫu `tpl: "do_de"` có 5 nhịp, viết vào `beats`, mỗi phần tử là **một dòng phụ đề
nằm trên một cảnh**:

| nhịp | nội dung | số dòng |
|---|---|---|
| `hook` | câu mở, phải chặn ngón tay người ta lại trong 2 giây | 1 |
| `khoanhkhac` | lúc con ra, tiếng khóc đầu, da kề da | 2–3 |
| `giadinh` | bố và ông bà ngoài cửa, cái chờ đợi | 2 |
| `chaomung` | chào con, một câu ấm | 1 |
| `nhavia` | nhả vía cho mẹ bầu + cảm ơn bác sĩ | 2 |

Luật viết, không được phá:

- **Tối đa 36 ký tự một dòng** (`subMax`). Dài hơn là app cắt mẩu, chữ nhảy hai
  hàng, xấu.
- Tiếng Việt nói chuyện, không văn vở. "Con bình an đến bên mẹ rồi." được;
  "Thiên thần nhỏ đã hạ cánh xuống vòng tay mẫu tử" thì không.
- Gọi "con", "mẹ", "bố", "bà" — đừng gọi "sản phụ", "em bé sơ sinh", "ca sinh".
- **Không hứa chuyên môn**: không "mẹ tròn con vuông 100%", không số đo Apgar,
  không "sinh thường không đau". Cảm xúc thì được, cam kết y tế thì không.
- Emoji nhiều nhất một cái, ở nhịp cuối, khi `emoji: true`.
- Tên bác sĩ chỉ nên xuất hiện một lần, ở `nhavia`.

Riêng câu `hook`: **viết 3 câu rồi mới chọn 1**, ba câu phải khác kiểu nhau (tò mò /
kể / cảm xúc / so sánh / chứng kiến) chứ đừng ba biến thể của cùng một ý. Câu đầu
tiên nghĩ ra gần như không bao giờ là câu hay nhất. Trong app có sẵn nút
"🎣 Gợi 3 câu móc" làm đúng việc này nếu người dùng bí.

Viết xong, tự soát lại cả bài theo hai nhóm — app cũng tự soát và hiện thẻ nhắc ở
tab 2, nhưng đừng để nó phải nhắc:

- **phải đổi**: cam kết, đảm bảo, tuyệt đối, 100%, chữa khỏi, khỏi hẳn, đặc trị,
  số 1, tốt nhất, duy nhất, không đau, không biến chứng, an toàn tuyệt đối;
- **nên tránh**: băng huyết, xuất huyết, chảy máu, máu, tai biến, biến chứng,
  nhiễm trùng, suy thai, ngạt, hồi sức, cấp cứu, rạch, khâu, vết mổ, tử vong.

"Sinh mổ", "đau đẻ" thì dùng bình thường — đây là chặn nói quá và tả thân thể, không
phải bắt nói sai chuyên môn. Đây là kinh nghiệm rút từ tài liệu khoá học, không phải
quy định chính thức của Facebook hay TikTok.

Mẫu sẵn trong `assets/mau-ca-do-de.json` là giọng đúng — đọc nó trước khi viết,
rồi viết bộ mới cùng tông chứ đừng copy y nguyên cho mọi ca.

## Nặn file mẫu

Đọc `assets/mau-ca-do-de.json`, thay `beats` + `bs`/`bv`/`pk`/`be` + `ten`, giữ
nguyên các khóa khác trừ khi người dùng đòi đổi. Ghi ra một file `.json` mới và
đưa cho họ cùng đường dẫn tới app.

Các khóa đáng biết khi họ muốn chỉnh:

- `hold` — số giây trung bình một ảnh nằm trên khung. **2.5 là nhịp đúng.** Lên 4
  là clip đứng hình; dưới 1.8 là nhấp nháy.
- `xf` — độ dài chuyển cảnh, giây. 0.35. Để 0.6 trở lên là mọi thứ nhoè vào nhau.
- `subColor` — màu chữ, `#ffb6d5` hồng.
- `fit` — `"blur"` (ảnh 3:4 nằm giữa, hai bên là chính nó làm mờ) hoặc `"cover"`
  (cắt đầy khung, mất rìa ảnh).
- `look` — lớp màu ấm. Tắt nếu họ muốn màu y tế thật.
- `dedup` — lọc ảnh chụp liên thanh giống nhau. Để `true`.
- `card` + `cardT/cardS/cardN/cardC` — thẻ cuối app tự vẽ. **App tự bỏ thẻ này
  khi có file outro riêng**, nên có outro thì không cần sửa gì ở đây.
- `music` — một trong `am_ap`, `con_yeu`, `hy_vong`, `beat_nhe`, `nen_diu_nhe`,
  `cam_hung`. Sáu bài này app tự sinh ra, không vướng bản quyền của ai.

Không ghi `outroId` vào mẫu: nó là id của một file trên đúng máy đó. App tự nhận
outro theo tên file (`outtro`/`outro` trong tên).

## Chỉ việc chỉ cho họ bấm

App không cần Claude mới chạy. Hướng dẫn gọn:

1. Nháy đúp `auto-edit-studio.html` (Chrome hoặc Edge; Firefox xuất không được).
2. Kéo thư mục ảnh + file outro vào ô giữa.
3. Tab 4 → mục "Mẫu — gửi cho người khác" → "Mở mẫu .json" → chọn file bạn vừa đưa.
4. Tab 2 → đọc lại kịch bản → DUYỆT.
5. Tab 4 → "Bắt đầu xuất". Xuất chạy theo thời gian thật và **phải để tab đó hiện
   trên màn hình**, chuyển cửa sổ là video đứng giữa.

## Bản quyền nhạc — nói thẳng điều này

Ô "Tiếng trong file xuất" để mặc định **"Không tiếng gì cả"**, và đó là lựa chọn
đúng. Nhạc trong thư viện CapCut và TikTok chỉ được cấp phép khi chèn **ngay
trong hai app đó**; lôi ra ngoài rồi mang vào là đường dễ bị tắt tiếng. Facebook
cũng không hề "không bị bản quyền" — Meta có Rights Manager, và với Trang doanh
nghiệp thì còn soi gắt hơn trang cá nhân.

Nên: xuất mp4 không tiếng → kéo vào CapCut → chọn nhạc bên đó (lọc tag **Thương
mại** nếu đăng cho Trang phòng khám) → xuất lại. Hoặc dùng Meta Sound Collection.

Đừng đi tải nhạc trending về làm kho nhạc — đó là sao chép bản ghi có bản quyền,
và nó không giải quyết được gì vì chèn sẵn ở ngoài vẫn là đường rủi ro.

## Và một việc không được bỏ qua

Ảnh ca đỡ đẻ có mặt sản phụ, mặt nhân viên, nhiều khi đọc được cả vòng tay số hồ
sơ. Mỗi lần làm clip, nhắc người dùng một câu: đã xin phép gia đình chưa, và có
cần che thông tin không. App có mục "Che thẻ tên / thông tin" ở tab 3 — một ô mờ
kéo được về đúng chỗ. Nhắc, rồi để họ quyết; đừng tự đăng hộ ai cái gì.
